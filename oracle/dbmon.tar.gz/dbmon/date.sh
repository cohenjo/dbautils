#date=sysdate
echo "2 days date = $date"
