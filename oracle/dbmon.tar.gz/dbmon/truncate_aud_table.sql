truncate table sys.aud$;
