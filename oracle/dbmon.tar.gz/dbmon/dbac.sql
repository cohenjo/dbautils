set feedback on heading on termout on 
show user
