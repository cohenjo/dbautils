@@latchprofx sid,name,func,hmode,objtype,object "&1" "&2" &3
