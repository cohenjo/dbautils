host " doskey /history /exename=sqlplus.exe | find /i /n "&1" | find /v "]@h " "
