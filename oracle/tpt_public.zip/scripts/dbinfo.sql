select dbid, name, created, log_mode, checkpoint_change#, open_mode, force_logging from v$database;
