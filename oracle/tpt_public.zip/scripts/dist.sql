prompt select distinct &1 from &2;
select distinct &1 from &2;
