set echo off
