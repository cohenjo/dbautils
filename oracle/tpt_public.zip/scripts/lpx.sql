prompt @latchprofx sid,name,func,hmode "&1" "&2" &3
@@latchprofx sid,name,func,hmode "&1" "&2" &3
