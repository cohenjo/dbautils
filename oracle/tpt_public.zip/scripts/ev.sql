@oerr &1
prompt alter session set events '&1 trace name context forever, level &2';;
alter session set events '&1 trace name context forever, level &2';
