prompt alter session set session_cached_cursors=&1;;
alter session set session_cached_cursors=&1
/
